﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DeadZone : MonoBehaviour
{
    //OnTrigger Collision
    void OnTriggerEnter(Collider other)
    {
        ScoreScript.scoreValue += 1; 
        Destroy(other.gameObject);
    }

}
