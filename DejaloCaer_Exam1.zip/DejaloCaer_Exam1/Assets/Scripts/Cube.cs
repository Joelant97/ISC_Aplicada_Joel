﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Cube : MonoBehaviour
{

    public Vector3 rot;
    public Vector3 angleToRot;
    // Start is called before the first frame update

    void Start()
    {
        Quaternion yRotation = Quaternion.AngleAxis(rot.y, Vector3.up);
        Quaternion xRotation = Quaternion.AngleAxis(rot.x, Vector3.right);
        Quaternion zRotation = Quaternion.AngleAxis(rot.z, Vector3.forward);
        this.transform.rotation = yRotation * xRotation * zRotation;
    }

    // Update is called once per frame
    
    void Update()
    {
        Quaternion yRotation = Quaternion.AngleAxis(angleToRot.y * Time.deltaTime, Vector3.up);
        Quaternion xRotation = Quaternion.AngleAxis(angleToRot.x * Time.deltaTime, Vector3.right);
        Quaternion zRotation = Quaternion.AngleAxis(angleToRot.z * Time.deltaTime, Vector3.forward);
        this.transform.rotation = yRotation * xRotation * zRotation * this.transform.rotation;

        rot += angleToRot * Time.deltaTime;


    }
}
