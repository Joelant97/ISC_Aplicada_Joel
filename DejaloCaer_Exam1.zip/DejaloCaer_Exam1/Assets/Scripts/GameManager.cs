﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    public Player player;
    public Cube cube;
    public CubeBlue cubeBlue; 

    //public DeadZone deadZone;

    public static Vector2 topRight;
    public static Vector2 bottomLeft;

    // Start is called before the first frame update
    void Start()
    {
        bottomLeft = Camera.main.ScreenToWorldPoint(new Vector2(0, 0));
        topRight = Camera.main.ScreenToWorldPoint(new Vector2(Screen.width, Screen.height));


        Player player1 = Instantiate(player) as Player;
        player1.Init(false);

        //Instantiate(deadZone);


        float randomSecnd = Random.Range(4, 6);
 
        InvokeRepeating("inst", 2f, randomSecnd);
        InvokeRepeating("inst2", 3f, randomSecnd);


    }

    // Update is called once per frame
    void Update()
    {

    }

    void inst()
    {
        float randomSecnd2 = Random.Range(-10, 10);
        Instantiate(cube, new Vector3(randomSecnd2, 4f, -0.084f), transform.rotation);

    }

    void inst2()
    {
        float randomSecnd2 = Random.Range(-10, 10);
        Instantiate(cubeBlue, new Vector3(randomSecnd2, 4f, -0.084f), transform.rotation);
    }

}
